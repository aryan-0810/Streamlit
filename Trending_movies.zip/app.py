import streamlit as st
import pandas as pd
import requests

st.set_page_config(page_title="Trending Movies")

st.title("Trending Movies")

url = "https://api.themoviedb.org/3/trending/movie/day"

st.write("Trending Movies App")

movies = pd.DataFrame({
    "Movie": [
        "Inception",
        "Interstellar",
        "The Dark Knight",
        "Avengers: Endgame",
        "Dangal"
    ],
    "Genre": [
        "Sci-Fi",
        "Sci-Fi",
        "Action",
        "Action",
        "Drama"
    ],
    "Rating": [
        8.8,
        8.7,
        9.0,
        8.4,
        8.3
    ]
})

st.dataframe(movies)