import pickle
from sklearn.ensemble import RandomForestClassifier

X = [
    [150, 120, 8],
    [120, 150, 7],
    [180, 160, 9],
    [130, 170, 5],
    [200, 150, 10],
    [140, 180, 4],
    [160, 155, 8],
    [110, 140, 6],
    [190, 130, 9],
    [125, 175, 5],
    [170, 160, 7],
    [135, 165, 4]
]

y = [
    "Team 1",
    "Team 2",
    "Team 1",
    "Team 2",
    "Team 1",
    "Team 2",
    "Team 1",
    "Team 2",
    "Team 1",
    "Team 2",
    "Team 1",
    "Team 2"
]

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

with open("ipl_model.pkl", "wb") as file:
    pickle.dump(model, file)

print("IPL model saved successfully as ipl_model.pkl")